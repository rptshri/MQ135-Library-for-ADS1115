## MQ-135 Air Quality / Gas Sensor

This code compatible with severals Arduino Board

Original Articles: https://hackaday.io/project/3475-sniffing-trinket/log/12363-mq135-arduino-library<br/>
MQ-135 Library: https://github.com/ckalpha/MQ135<br/>
Author: Damrongwit Nusuk<br/>
Email: jack@racksync.com<br/>
Visit Website: http://www.racksync.com<br/>
Website : http://www.racksync.com<br/>

<img src="http://www.haoyuelectronics.com/Attachment/MQ135/MQ135-1.jpg">
